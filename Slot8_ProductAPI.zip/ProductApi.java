package com.mycompany.mavenproject7;

import jakarta.servlet.*;
import jakarta.servlet.http.*;
import jakarta.servlet.annotation.*;
import java.io.*;
import java.sql.*;
import org.json.JSONArray;
import org.json.JSONObject;

@WebServlet("/api/products")
public class ProductApi extends HttpServlet {
    private static final String URL = "jdbc:mysql://localhost:3306/a1";
    private static final String USER = "root";
    private static final String PASS = "";

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp)
            throws IOException {
        // Bật CORS để HTML có thể gọi được
        resp.setHeader("Access-Control-Allow-Origin", "*");
        resp.setHeader("Access-Control-Allow-Methods", "GET, POST, OPTIONS");
        resp.setHeader("Access-Control-Allow-Headers", "Content-Type");

        resp.setContentType("application/json");
        resp.setCharacterEncoding("UTF-8");

        JSONArray products = new JSONArray();

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection conn = DriverManager.getConnection(URL, USER, PASS);
            Statement st = conn.createStatement();
            ResultSet rs = st.executeQuery("SELECT * FROM mytable");

            while (rs.next()) {
                JSONObject obj = new JSONObject();
                obj.put("styleid", rs.getInt("styleid"));
                obj.put("search_image", rs.getString("search_image"));
                obj.put("brands_filter_facet", rs.getString("brands_filter_facet"));
                obj.put("price", rs.getInt("price"));
                obj.put("product_additional_info", rs.getString("product_additional_info"));
                products.put(obj);
            }
            
            conn.close();
        } catch (Exception e) {
            e.printStackTrace();
        }

        JSONObject result = new JSONObject();
        result.put("products", products);
        resp.getWriter().print(result.toString());
    }
}
